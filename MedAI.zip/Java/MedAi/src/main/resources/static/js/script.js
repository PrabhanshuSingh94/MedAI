const typed = new Typed('.multiple-text', {
    strings: ['MedAI',"Future is here.."],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});

const t = new Typed('.cancer-text', {
    strings: ['Breast Cancer Prediction'],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});
const tb = new Typed('.brain-text', {
    strings: ["Brain Tumor Prediction"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});

const tb1 = new Typed('.diabetes-text', {
    strings: ["Diabetes Prediction"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});

  AOS.init();
